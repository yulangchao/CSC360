You've found the first file on disk1.img.

Great work!  Can you find the second file too?

